import "dotenv/config";
import express from "express";
import { askAI } from "./openrouter.js";
import { sendMessage } from "./whatsapp.js";

const app = express();
app.use(express.json());

// Webhook verify
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === process.env.VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Incoming message
app.post("/webhook", async (req, res) => {
  try {
    const msg =
      req.body.entry?.[0]?.changes?.[0]?.value?.messages?.[0];

    if (!msg?.text) return res.sendStatus(200);

    const from = msg.from;
    const text = msg.text.body;

    const reply = await askAI(text);
    await sendMessage(from, reply);

    res.sendStatus(200);
  } catch (err) {
    console.error("ERROR:", err.message);
    res.sendStatus(200);
  }
});

app.listen(process.env.PORT, () => {
  console.log(`🚀 Bot running on port ${process.env.PORT}`);
});