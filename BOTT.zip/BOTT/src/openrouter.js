import axios from "axios";

export async function askAI(message) {
  const res = await axios.post(
    "https://openrouter.ai/api/v1/chat/completions",
    {
      model: process.env.OPENROUTER_MODEL,
      messages: [
        { role: "system", content: "Kamu asisten WhatsApp yang ramah dan singkat." },
        { role: "user", content: message }
      ]
    },
    {
      headers: {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://example.com",
        "X-Title": "WA OpenRouter Bot"
      }
    }
  );

  return res.data.choices[0].message.content;
}