## Telegram Bot (Telegraf)

### Setup
1. Buat file `.env` dari contoh:
   ```bash
   cp .env.example .env