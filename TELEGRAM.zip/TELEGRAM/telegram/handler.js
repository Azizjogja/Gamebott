"use strict";

/**
 * Telegram dispatcher:
 * - Built-in commands: /start /menu /help
 * - Games: /tebakgambar /tebakkata /susunkata + answer parsing + /nyerah
 * - AI: /ai + /ai_on /ai_off + memory (10) + rate limit (3s)
 * - Legacy plugins: pass through lib/handler.js (best effort)
 * - Never crash if plugin error
 */

const fs = require("fs");
const path = require("path");
const OpenAI = require("openai");

// Legacy plugin loader in repo (DON'T DELETE)
const legacyPluginHandler = require("../lib/handler");

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function normalizeAnswer(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function makeHint(answer) {
  return String(answer || "").replace(
    /[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,
    "-"
  );
}

function safeMarkdown(text) {
  // minimal escaping to reduce Telegram markdown error
  return String(text || "").replace(/([_*`[\]()~>#+\-=|{}.!])/g, "\\$1");
}

function createTelegramHandler({ bot }) {
  const ROOT = process.cwd();
  const GAME_DIR = path.join(ROOT, "Game");

  // Load JSON game data (keep using legacy folder)
  const datasets = {
    tebakgambar: JSON.parse(
      fs.readFileSync(path.join(GAME_DIR, "tebakgambar.json"), "utf8")
    ),
    tebakkata: JSON.parse(
      fs.readFileSync(path.join(GAME_DIR, "tebakkata.json"), "utf8")
    ),
    susunkata: JSON.parse(
      fs.readFileSync(path.join(GAME_DIR, "susunkata.json"), "utf8")
    ),
  };

  // --- Game sessions per chat ---
  const gameSessions = new Map(); // chatId -> { type, answer, answerOriginal, meta, timeout }
  const GAME_TIMEOUT_MS = 60_000;

  function endGame(chatId) {
    const key = String(chatId);
    const s = gameSessions.get(key);
    if (s?.timeout) clearTimeout(s.timeout);
    gameSessions.delete(key);
    return s || null;
  }

  function startGame(chatId, type, onTimeoutNotify) {
    const key = String(chatId);
    endGame(key);

    const data = pickRandom(datasets[type]);
    const answerOriginal = String(data.jawaban || "");
    const answer = normalizeAnswer(answerOriginal);

    const session = {
      type,
      answer,
      answerOriginal,
      meta: data,
      timeout: setTimeout(async () => {
        const ended = endGame(key);
        if (!ended) return;
        try {
          await onTimeoutNotify(ended);
        } catch (e) {
          console.error("Game timeout notify error:", e);
        }
      }, GAME_TIMEOUT_MS),
    };

    gameSessions.set(key, session);
    return session;
  }

  // --- AI (OpenAI) ---
  const aiEnabledChats = new Set(); // chatIds
  const aiMemory = new Map(); // chatId -> [{role, content}]
  const aiLastCall = new Map(); // userId -> timestamp

  const AI_RATE_LIMIT_MS = 3000;
  const AI_MEMORY_SIZE = 10;

  const openaiKey = process.env.OPENAI_API_KEY || "";
  const openaiModel = process.env.OPENAI_MODEL || "gpt-4o-mini";
  const openai = openaiKey ? new OpenAI({ apiKey: openaiKey }) : null;

  function aiPush(chatId, role, content) {
    const key = String(chatId);
    const arr = aiMemory.get(key) || [];
    arr.push({ role, content: String(content) });
    while (arr.length > AI_MEMORY_SIZE) arr.shift();
    aiMemory.set(key, arr);
  }

  async function askAI({ chatId, userId, text }) {
    if (!openai) return "OPENAI_API_KEY belum di-set. Isi .env dulu ya.";

    const now = Date.now();
    const last = aiLastCall.get(String(userId)) || 0;
    if (now - last < AI_RATE_LIMIT_MS) {
      const wait = Math.ceil((AI_RATE_LIMIT_MS - (now - last)) / 1000);
      return `⏳ Rate limit: coba lagi dalam ~${wait} detik.`;
    }
    aiLastCall.set(String(userId), now);

    aiPush(chatId, "user", text);
    const history = aiMemory.get(String(chatId)) || [];

    const messages = [
      {
        role: "system",
        content:
          "Kamu adalah asisten AI untuk bot Telegram. Jawab bahasa Indonesia yang ramah, jelas, dan ringkas.",
      },
      ...history,
    ];

    const res = await openai.chat.completions.create({
      model: openaiModel,
      messages,
      temperature: 0.7,
    });

    const ans = res.choices?.[0]?.message?.content?.trim() || "(tidak ada jawaban)";
    aiPush(chatId, "assistant", ans);
    return ans;
  }

  // --- Telegram socket shim for legacy plugins (best-effort) ---
  const tgSocket = {
    sendMessage: async (chatId, content, opts = {}) => {
      try {
        if (typeof content === "string") {
          return await bot.telegram.sendMessage(String(chatId), content, opts);
        }
        if (content?.text) {
          return await bot.telegram.sendMessage(
            String(chatId),
            String(content.text),
            opts
          );
        }
        if (content?.image) {
          const url = content.image.url || content.image;
          const caption = content.caption;
          return await bot.telegram.sendPhoto(String(chatId), url, {
            caption,
            ...opts,
          });
        }
        if (content?.document) {
          const url = content.document.url || content.document;
          const caption = content.caption;
          return await bot.telegram.sendDocument(String(chatId), url, {
            caption,
            ...opts,
          });
        }
        return await bot.telegram.sendMessage(
          String(chatId),
          "[Unsupported message]",
          opts
        );
      } catch (e) {
        console.error("tgSocket.sendMessage error:", e);
      }
    },
  };

  // --- Built-in commands ---
  async function handleBuiltins(ctx, m, meta) {
    const chatId = m.chat;

    if (meta.command === "start") {
      return m.reply(
        [
          `Halo ${m.pushName}!`,
          "Aku Cantarella versi Telegram.",
          "",
          "Perintah:",
          "/menu - daftar fitur",
          "/ai <pesan> - chat AI",
          "/ai_on - mode AI di chat ini",
          "/ai_off - matikan mode AI",
          "/tebakgambar /tebakkata /susunkata - game",
        ].join("\n")
      );
    }

    if (meta.command === "menu" || meta.command === "help") {
      const msg =
        "📌 *Menu Cantarella Telegram*\n\n" +
        "🤖 AI\n" +
        "• /ai <pesan>\n" +
        "• /ai_on (mode AI untuk chat ini)\n" +
        "• /ai_off\n\n" +
        "🎮 Game\n" +
        "• /tebakgambar\n" +
        "• /tebakkata\n" +
        "• /susunkata\n" +
        "• /nyerah\n\n" +
        "🧩 Plugin legacy\n" +
        "• Semua command lama dipetakan ke /command (best-effort)";
      return m.reply(msg, { parse_mode: "Markdown" });
    }

    if (meta.command === "ai") {
      const prompt = (meta.args || []).join(" ").trim();
      if (!prompt) return m.reply("Format: /ai <pesan>");

      try {
        const ans = await askAI({ chatId, userId: m.sender, text: prompt });
        return m.reply(ans);
      } catch (e) {
        console.error("AI error:", e);
        return m.reply("Terjadi error saat memproses AI.");
      }
    }

    if (meta.command === "ai_on") {
      aiEnabledChats.add(String(chatId));
      return m.reply(
        "✅ Mode AI aktif di chat ini. Ketik pesan biasa untuk ngobrol. /ai_off untuk mematikan."
      );
    }

    if (meta.command === "ai_off") {
      aiEnabledChats.delete(String(chatId));
      return m.reply("🛑 Mode AI dimatikan.");
    }

    // Games
    if (meta.command === "tebakgambar") {
      const s = startGame(chatId, "tebakgambar", async (ended) => {
        await bot.telegram.sendMessage(
          String(chatId),
          `Waktu habis! Jawabannya: ${ended.answerOriginal}`
        );
      });

      const d = s.meta;
      const caption =
        `*GAME TEBAK GAMBAR*\n\n` +
        `Petunjuk: \`${safeMarkdown(makeHint(d.jawaban))}\`\n` +
        (d.deskripsi ? `Deskripsi: ${safeMarkdown(d.deskripsi)}\n` : "") +
        `Waktu: 60 detik\n\n` +
        `Ketik jawaban (tanpa /). Menyerah: /nyerah`;

      try {
        await bot.telegram.sendPhoto(String(chatId), d.img, {
          caption,
          parse_mode: "Markdown",
        });
      } catch (e) {
        console.error("sendPhoto error:", e);
        await m.reply("Gagal mengirim gambar. Coba lagi.");
      }
      return true;
    }

    if (meta.command === "tebakkata") {
      const s = startGame(chatId, "tebakkata", async (ended) => {
        await bot.telegram.sendMessage(
          String(chatId),
          `Waktu habis!\n\nSoal: ${ended.meta.soal}\nJawaban: ${ended.answerOriginal}`
        );
      });

      const d = s.meta;
      const msg =
        `*GAME TEBAK KATA*\n\n` +
        `Soal: ${safeMarkdown(d.soal)}\n` +
        `Petunjuk: \`${safeMarkdown(makeHint(d.jawaban))}\`\n` +
        `Waktu: 60 detik\n\n` +
        `Ketik jawaban (tanpa /). Menyerah: /nyerah`;
      await m.reply(msg, { parse_mode: "Markdown" });
      return true;
    }

    if (meta.command === "susunkata") {
      const s = startGame(chatId, "susunkata", async (ended) => {
        await bot.telegram.sendMessage(
          String(chatId),
          `Waktu habis!\n\nSoal: ${ended.meta.soal}\nJawaban: ${ended.answerOriginal}`
        );
      });

      const d = s.meta;
      const msg =
        `*GAME SUSUN KATA*\n\n` +
        `Soal: *${safeMarkdown(d.soal)}*\n` +
        `Petunjuk: \`${safeMarkdown(makeHint(d.jawaban))}\`\n` +
        `Waktu: 60 detik\n\n` +
        `Ketik jawaban (tanpa /). Menyerah: /nyerah`;
      await m.reply(msg, { parse_mode: "Markdown" });
      return true;
    }

    if (meta.command === "nyerah") {
      const ended = endGame(chatId);
      if (!ended) {
        await m.reply("Tidak ada game yang sedang berjalan.");
        return true;
      }
      await m.reply(`😅 Menyerah ya... Jawabannya: ${ended.answerOriginal}`);
      return true;
    }

    return false;
  }

  // --- Answer game by normal chat (non-command) ---
  async function handleGameAnswer(m, meta) {
    if (meta.isCmd) return false;

    const session = gameSessions.get(String(m.chat));
    if (!session) return false;

    const userAns = normalizeAnswer(m.text);
    if (!userAns) return false;

    if (userAns === session.answer) {
      endGame(m.chat);
      await m.reply(`✅ Benar! Jawabannya: ${session.answerOriginal}`);
      return true;
    }

    return false;
  }

  // --- AI mode: if enabled OR reply to bot ---
  async function handleAiChatMode(ctx, m, meta) {
    if (meta.isCmd) return false;

    const chatId = String(m.chat);
    const repliedToBot = Boolean(ctx.message?.reply_to_message?.from?.is_bot);

    if (!aiEnabledChats.has(chatId) && !repliedToBot) return false;

    try {
      const ans = await askAI({ chatId, userId: m.sender, text: m.text });
      await m.reply(ans);
      return true;
    } catch (e) {
      console.error("AI mode error:", e);
      await m.reply("Terjadi error saat memproses AI.");
      return true;
    }
  }

  // --- Legacy plugin dispatch (/command) ---
  async function dispatchLegacyPlugins(m, meta) {
    if (!meta.isCmd || !meta.command) return false;

    // Skip built-ins (avoid double processing)
    const builtins = new Set([
      "start",
      "menu",
      "help",
      "ai",
      "ai_on",
      "ai_off",
      "tebakgambar",
      "tebakkata",
      "susunkata",
      "nyerah",
    ]);
    if (builtins.has(meta.command)) return false;

    const Obj = {
      Cantarella: tgSocket,
      Zion: tgSocket,
      reply: (t) => m.reply(t),
      text: (meta.args || []).join(" "),
      args: meta.args || [],
      command: meta.command,
      isCmd: true,
      mime: "",
      qmsg: m.quoted || null,
      isOwner: false,
    };

    try {
      await legacyPluginHandler(m, meta.command, Obj);
      return true;
    } catch (e) {
      console.error("Legacy plugin dispatch error:", e);
      await m.reply("Terjadi error saat menjalankan plugin.");
      return true;
    }
  }

  async function handleText(ctx, m, meta) {
    try {
      // 1) answer game if active
      if (await handleGameAnswer(m, meta)) return;

      // 2) handle built-in commands
      if (meta.isCmd) {
        const handled = await handleBuiltins(ctx, m, meta);
        if (handled) return;
      }

      // 3) AI mode (non-command)
      if (await handleAiChatMode(ctx, m, meta)) return;

      // 4) legacy plugins
      if (await dispatchLegacyPlugins(m, meta)) return;

      // else do nothing
    } catch (e) {
      console.error("Handler error:", e);
      try {
        await m.reply("Terjadi error…");
      } catch {}
    }
  }

  return { handleText };
}

module.exports = { createTelegramHandler };