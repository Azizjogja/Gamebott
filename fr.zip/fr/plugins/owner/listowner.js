const config = require('../../config')

const pluginConfig = {
    name: 'listowner',
    alias: ['ownerlist', 'owners'],
    category: 'owner',
    description: 'Melihat daftar owner bot',
    usage: '.listowner',
    example: '.listowner',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    limit: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const ownerNumbers = config.owner?.number || []
    
    if (ownerNumbers.length === 0) {
        return m.reply(`👑 *ʟɪsᴛ ᴏᴡɴᴇʀ*\n\n> Tidak ada owner yang terdaftar`)
    }
    
    let txt = `👑 *ʟɪsᴛ ᴏᴡɴᴇʀ*\n\n`
    txt += `╭┈┈⬡「 📋 *ᴏᴡɴᴇʀs* 」\n`
    
    for (let i = 0; i < ownerNumbers.length; i++) {
        txt += `┃ ${i + 1}. \`${ownerNumbers[i]}\`\n`
    }
    
    txt += `╰┈┈⬡\n\n`
    txt += `> ᴛᴏᴛᴀʟ: \`${ownerNumbers.length}\` ᴏᴡɴᴇʀ`
    
    await m.reply(txt)
}

module.exports = {
    config: pluginConfig,
    handler
}
